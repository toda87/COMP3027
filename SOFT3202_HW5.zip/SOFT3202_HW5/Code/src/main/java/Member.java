/**
 * Interface for all concrete member classes.
 */
public interface Member {

  /**
   * @param product  The product to be selected. May not be null.
   * @param quantity The number of units of the product to be selected. Must be 1 or more.
   * @throws IllegalArgumentException if any of the parameter preconditions are breached.
   * @throws IllegalStateException    if the global inventory does not have the required amount of
   *                                  Product.
   */
  void selectProduct(Product product, int quantity);

  /**
   * @param product  The product to be returned.
   * @param quantity The number of units of the product to be returned.
   * @throws IllegalArgumentException if any of the parameter preconditions are breached.
   * @throws IllegalStateException    if the Member's basket does not contain the required amount of
   *                                  Product.
   */
  void returnProduct(Product product, int quantity);

  /**
   * Finalise the payment. Do not charge anything if the basket is empty.
   */
  void finalisePurchases();
}
