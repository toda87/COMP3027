/**
 * Interface for all concrete product classes.
 */
public interface Product {

  /**
   * Standard name accessor. Throws no exceptions.
   *
   * @return The name for this product. Will not be null or the empty string.
   */
  String getName();

  /**
   * Standard price accessor. Throws no exceptions.
   *
   * @return The price of a single unit of this product. Will be greater than 0.
   */
  double getPrice();
}
