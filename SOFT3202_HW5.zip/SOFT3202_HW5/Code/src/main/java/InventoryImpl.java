import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Inventory for Store. Should be initialized in Store class.
 */
public class InventoryImpl implements Inventory {

  private HashMap<Product, Integer> storage = new HashMap<>();

  /**
   * Default constructor.
   */
  public InventoryImpl() {
  }

  /**
   * Adds a number of a product to this inventory.
   *
   * @param product  The product to add. May not be null.
   * @param quantity The amount to add. Must be 1 or more.
   * @throws IllegalArgumentException if any of the parameter preconditions are breached.
   */
  public void addProduct(Product product, int quantity) throws IllegalArgumentException {
    if (product == null || quantity < 1) {
      throw new IllegalArgumentException();
    }
    if (!storage.containsKey(product)) {
      storage.put(product, quantity);
    } else {
      storage.put(product, storage.get(product) + quantity);
    }
  }


  /**
   * Removes a number of a product from this inventory.
   *
   * @param product  The product to remove. May not be null.
   * @param quantity The amount to remove. Must be 1 or more.
   * @throws IllegalArgumentException if any of the parameter preconditions are breached.
   * @throws IllegalStateException    if the inventory did not hold at least the requested amount of
   *                                  the given product.
   */
  public void takeProduct(Product product, int quantity)
      throws IllegalArgumentException, IllegalStateException {
    if (product == null || quantity < 1) {
      throw new IllegalArgumentException();
    }
    if (!storage.containsKey(product) || storage.get(product) < quantity) {
      throw new IllegalStateException();
    }

    storage.put(product, storage.get(product) - quantity);
  }


  /**
   * Accessor for the count of a product.
   *
   * @param product The product to view the count for. May not be null.
   * @return The number of units of the given product stored in this inventory. Will be 0 or more.
   * @throws IllegalArgumentException if any of the parameter preconditions are breached.
   */
  public int getProductQuantity(Product product) throws IllegalArgumentException {
    if (product == null) {
      throw new IllegalArgumentException();
    }
    return storage.get(product);
  }

  /**
   * Accessor for the list of products.
   *
   * @return The list of products currently OR previously stored in this inventory. 0 count products
   * will still be listed.
   */
  public List<Product> getProducts() {
    List<Product> list = new ArrayList<>(storage.keySet());

    return list;
  }


}
