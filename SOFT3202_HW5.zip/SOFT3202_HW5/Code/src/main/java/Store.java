/**
 * Representation of a store
 */
public class Store {

  /**
   * Generic driver method
   *
   * @param args command line arguments
   */
  public static void main(String[] args) {

  }
}
