import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;

import org.junit.Before;
import org.junit.Test;

/**
 * Test InventoryImpl class
 */
public class InventoryImplTest {

  private Inventory inventory;
  Product pear = mock(ProductImpl.class);
  Product apple = mock(ProductImpl.class);
  Product banana = mock(ProductImpl.class);

  /**
   * Create inventory instance before each test.
   */
  @Before
  public void init() {
    inventory = new InventoryImpl();
  }

  /**
   * Test addProduct() on null, empty, negative and valid parameters.
   */
  @Test
  public void addProduct() {
    //Test for null product
    try {
      inventory.addProduct(null, 3);
      fail();
    } catch (IllegalArgumentException e) {
      //check the error message
    }

    //Test for zero quantity
    try {
      inventory.addProduct(apple, 0);
      fail();
    } catch (IllegalArgumentException e) {
      //check the error message
    }

    //Test for negative quantity
    try {
      inventory.addProduct(apple, -1);
      fail();
    } catch (IllegalArgumentException e) {
      //check the error message
    }

    //Try adding valid products
    inventory.addProduct(apple, 10);

    inventory.addProduct(banana, 10);
  }

  /**
   * Test takeProduct() on null, empty, negative and valid parameters.
   */
  @Test
  public void takeProduct() {
    //Test for null product
    try {
      inventory.takeProduct(null, 5);
      fail();
    } catch (IllegalArgumentException e) {
      //check error message
    }

    //Test for negative quantity
    try {
      inventory.takeProduct(apple, -1);
      fail();
    } catch (IllegalArgumentException e) {
      //check error message
    }

    //Test for zero quantity
    try {
      inventory.takeProduct(apple, 0);
      fail();
    } catch (IllegalArgumentException e) {
      //check error message
    }

    //Test for valid takeProduct()
    inventory.addProduct(banana, 10);
    inventory.takeProduct(banana, 5);
  }

  /**
   * Test getProductQuantity() on null and valid products.
   */
  @Test
  public void getProductQuantity() {
    //Test for null product
    try {
      inventory.getProductQuantity(null);
      fail();
    } catch (IllegalArgumentException e) {
      //check error message
    }

    //Test for valid getProductQuantity()
    inventory.addProduct(pear, 10);
    assertEquals(inventory.getProductQuantity(pear), 10);

    inventory.takeProduct(pear, 5);
    assertEquals(inventory.getProductQuantity(pear), 5);
  }


  /**
   * Test getProducts() if it can identify products in the inventory.
   */
  @Test
  public void getProducts() {
    int currentNumberOfProduct = inventory.getProducts().size();

    inventory.addProduct(apple, 10);
    inventory.addProduct(banana, 10);

    assertEquals(inventory.getProducts().size() - currentNumberOfProduct, 2);

    boolean p1Checker = false;
    boolean p2Checker = false;

    for (Product p : inventory.getProducts()) {
      if (apple == p) {
        p1Checker = true;
      }
      if (banana == p) {
        p2Checker = true;
      }
    }

    assertTrue(p1Checker);
    assertTrue(p2Checker);

    //Test if 0 count product is stil listed.
    inventory.takeProduct(apple, 10);

    p1Checker = false;

    for (Product p : inventory.getProducts()) {
      if (apple == p) {
        p1Checker = true;
      }
    }

    assertTrue(p1Checker);
  }
}