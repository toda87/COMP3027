import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Test ProductImpl class.
 */
public class ProductImplTest {

  /**
   * Test ProductImpl's constructor
   */
  //Test Constructor
  @Test
  public void productConstructorTest() {
    //Test for null named product
    try {
      Product product = new ProductImpl(null, 2.0);
      fail();
    } catch (IllegalArgumentException e) {
      //check error message
    }

    //Test for null empty named product
    try {
      Product product = new ProductImpl("", 2.0);
      fail();
    } catch (IllegalArgumentException e) {
      //check error message
    }

    //Test for negative priced product
    try {
      Product product = new ProductImpl("Apple", -1);
      fail();
    } catch (IllegalArgumentException e) {
      //check error message
    }

    //Test for zero priced product
    try {
      Product product = new ProductImpl("Apple", 0);
      fail();
    } catch (IllegalArgumentException e) {
      //check error message
    }

    //Test valid creation of product
    Product Apple = new ProductImpl("Apple", 1.0);
    Product Banana = new ProductImpl("Banana", 3.14);

    assertNotNull(Apple);
    assertNotNull(Banana);
  }

  /**
   * Test getName() if it returns correct product name.
   */
  @Test
  public void getName() {
    Product Apple = new ProductImpl("Apple", 1.0);
    Product Banana = new ProductImpl("Banana", 3.14);

    assertEquals(Apple.getName(), "Apple");
    assertEquals(Banana.getName(), "Banana");
  }

  /**
   * Test getPrice() if it returns correct product price.
   */
  @Test
  public void getPrice() {
    Product Apple = new ProductImpl("Apple", 1.0);
    Product Banana = new ProductImpl("Banana", 3.14);

    assertEquals(Apple.getPrice(), 1.0, 0.001);
    assertEquals(Banana.getPrice(), 3.14, 0.001);
  }
}