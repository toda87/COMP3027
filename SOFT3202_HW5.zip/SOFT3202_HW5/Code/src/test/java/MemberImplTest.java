import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

/**
 * Test for MemberImpl class.
 */
public class MemberImplTest {

  private Member member;
  private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
  private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
  private final PrintStream originalOut = System.out;
  private final PrintStream originalErr = System.err;

  @Mock
  Inventory inventory;
  ShoppingBasket sb;

  /**
   * Create mock data for inventory, shoppingBasket, and create member on those mock data before each test.
   * Also set output stream for comparing println().
   */
  @Before
  public void makeBasket() {
    inventory = mock(InventoryImpl.class);
    sb = mock(ShoppingBasketImpl.class);
    member = new MemberImpl(inventory, sb);
    System.setOut(new PrintStream(outContent));
    System.setErr(new PrintStream(errContent));
  }

  /**
   * Release output stream for comparing println().
   */
  @After
  public void restoreStreams() {
    System.setOut(originalOut);
    System.setErr(originalErr);
  }

  /**
   * Test selectProduct() on null, negative, zero inputs.
   */
  @Test
  public void selectProduct() {
    //Test when product is null
    try {
      member.selectProduct(null, 3);
      fail();
    } catch (IllegalArgumentException e) {
      //check error message
    }

    //Test when the quantity given is negative
    try {
      member.selectProduct(null, -1);
      fail();
    } catch (IllegalArgumentException e) {
      //check error message
    }

    //Test when the quantity given is zero
    try {
      member.selectProduct(null, 0);
      fail();
    } catch (IllegalArgumentException e) {
      //check error message
    }
    Product p = mock(ProductImpl.class);

    //This test should pass.
    when(inventory.getProductQuantity(p)).thenReturn(1);
    member.selectProduct(p, 1);
  }

  /**
   * Test returnProduct() on null, negative, zero inputs.
   */
  @Test
  public void returnProduct() {
    //Test when the product is null
    try {
      member.returnProduct(null, 3);
      fail();
    } catch (IllegalArgumentException e) {
      //check error message
    }

    Product p = mock(ProductImpl.class);

    //Test when the product quantity is negative
    try {
      member.returnProduct(p, -1);
      fail();
    } catch (IllegalArgumentException e) {
      //check error message
    }

    //Test when the product quantity is zero
    try {
      member.returnProduct(p, 0);
      fail();
    } catch (IllegalArgumentException e) {
      //check error message
    }

    //Test when trying to return product not in basket
    try {
      member.returnProduct(p, 1);
      fail();
    } catch (IllegalStateException e) {
      //check error message
    }

    when(sb.removeItem(p, 10)).thenReturn(false);

    //Test when trying to return product more than that is in the basket
    try {
      member.returnProduct(p, 10);
      fail();
    } catch (IllegalStateException e) {
      //check error message
    }

    //This test should pass
    when(sb.removeItem(p, 10)).thenReturn(true);
    member.returnProduct(p, 10);
  }

  /**
   * Test finalisePurchasesEmptyBasket() when the shopping basket is empty.
   */
  @Test
  public void finalisePurchasesEmptyBasket() {
    //When the shopping basket is empty
    when(sb.getValue()).thenReturn(null);
    member.finalisePurchases();
    assertEquals("There is nothing in the basket. Good bye." + System.lineSeparator(),
        outContent.toString());
  }

  /**
   * Test finalisePurchasesEmptyBasket() when the shopping basket is not empty.
   */
  @Test
  public void finalisePurchasesNonEmptyBasket() {
    when(sb.getValue()).thenReturn(130.20);
    assertEquals(sb.getValue(), 130.20, 0.001);
    member.finalisePurchases();
    assertEquals("Thank you for purchasing. The total charge is $130.20" + System.lineSeparator(),
        outContent.toString());
  }

}