import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.*;

import javafx.util.Pair;
import org.junit.Before;
import org.junit.Test;

/**
 * Test ShoppingBasketImpl class.
 */
public class ShoppingBasketImplTest {

  private ShoppingBasket sb;
  Product pear = mock(ProductImpl.class);
  Product apple = mock(ProductImpl.class);
  Product orange = mock(ProductImpl.class);
  Product banana = mock(ProductImpl.class);

  /**
   * Create shoppingBasket instance before each test.
   */
  @Before
  public void makeBasket() {
    sb = new ShoppingBasketImpl();
  }


  /**
   * Test addItem() if products are correctly added to the shoppingBasket of a member.
   */
  @Test
  public void addItemTest() {
    //Test when the product is null
    try {
      sb.addItem(null, 1);
      fail();
    } catch (IllegalArgumentException e) {
      //check error message
    }

    //Test when the given quantity is negative
    try {
      sb.addItem(apple, -1);
      fail();
    } catch (IllegalArgumentException e) {
      //check error message
    }

    //Test when the given quantity is zero
    try {
      sb.addItem(apple, 0);
      fail();
    } catch (IllegalArgumentException e) {
      //check error message
    }

    //Try valid inputs on addItem()
    sb.addItem(apple, 1);
    sb.addItem(apple, 10);
  }

  /**
   * Test removeItem() if it can successfully remove products from a member's shoppingBasket.
   */
  @Test
  public void removeItem() {
    //Test when given product is null
    try {
      sb.removeItem(null, 1);
      fail();
    } catch (IllegalArgumentException e) {
      //check error message
    }

    //Test when given quantity is negative
    try {
      sb.removeItem(apple, -1);
      fail();
    } catch (IllegalArgumentException e) {
      //check error message
    }

    //Test when given quantity is zero
    try {
      sb.removeItem(apple, 0);
      fail();
    } catch (IllegalArgumentException e) {
      //check error message
    }

    //Test removing product not in / more than it is in the basket
    assertFalse(sb.removeItem(apple, 1));

    //add 10 items and try removing it.
    sb.addItem(apple, 10);

    //Try removing valid quantity
    assertTrue(sb.removeItem(apple, 10));

    //Now that basket is empty, can't remove apple again.
    assertFalse(sb.removeItem(apple, 1));
  }

  /**
   * Test if getItems() successfully returns all products and quantities in a member's
   * shoppingBasket.
   */
  @Test
  public void getItems() {
    sb.addItem(apple, 10);
    sb.addItem(banana, 5);

    List<Pair<Product, Integer>> productList = sb.getItems();

    boolean appleInBasket = false;
    boolean bananaInBasket = false;

    for (int i = 0; i < productList.size(); i++) {
      if (productList.get(i).getKey() == apple && productList.get(i).getValue() == 10) {
        appleInBasket = true;
      }
      if (productList.get(i).getKey() == banana && productList.get(i).getValue() == 5) {
        bananaInBasket = true;
      }
    }

    assertTrue(appleInBasket);
    assertTrue(bananaInBasket);

    //remove all banana. getItems should not return banana
    bananaInBasket = false;
    sb.removeItem(banana, 5);

    for (int i = 0; i < productList.size(); i++) {
      if (productList.get(i).getKey() == banana) {
        bananaInBasket = true;
      }
    }
    assertTrue(bananaInBasket);
  }

  /**
   * Test if getValue() can sum the total value of a member's shoppingBasket.
   */
  @Test
  public void getValue() {

    //Test when there is nothing in the basket
    assertEquals(null, sb.getValue());

    sb.addItem(pear, 4);
    sb.addItem(apple, 3);
    sb.addItem(orange, 1);
    sb.addItem(banana, 1);

    when(pear.getPrice()).thenReturn(3.0);
    when(apple.getPrice()).thenReturn(2.5);
    when(orange.getPrice()).thenReturn(1.25);
    when(banana.getPrice()).thenReturn(4.95);

    assertEquals(pear.getPrice() * 4 + apple.getPrice() * 3 + orange.getPrice() + banana.getPrice(),
        sb.getValue(), 0.001);
  }

  /**
   * Test if clear() can remove all products in a member's shoppingBasket.
   */
  @Test
  public void clear() {
    sb.addItem(apple, 10);
    sb.addItem(banana, 20);
    sb.addItem(pear, 5);

    assertEquals(sb.getItems().size(), 3);
    sb.clear();

    assertEquals(sb.getItems().size(), 0);
  }
}