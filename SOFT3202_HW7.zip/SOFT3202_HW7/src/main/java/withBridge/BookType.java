package withBridge;

public interface BookType {
  String getBookType();
}
