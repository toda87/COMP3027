package withBridge;

public class BookImpl implements Book {

  private final BookLanguage language;
  private final BookLiterature literature;
  private final BookType type;
  private final BookLength length;

  public BookImpl(BookLanguage language, BookLiterature literature, BookType type, BookLength length){
    this.language = language;
    this.literature = literature;
    this.type = type;
    this.length = length;
  }

  @Override
  public void read() {
    System.out.println(language.getLanguageOutput());
    System.out.println(literature.getLiteratureType());
    System.out.println(type.getBookType());
    System.out.println(length.getBookLength());
  }
}
