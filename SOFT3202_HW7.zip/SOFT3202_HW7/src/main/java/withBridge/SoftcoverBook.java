package withBridge;

public class SoftcoverBook implements BookType{

  @Override
  public String getBookType() {
    return "This is a softcover book";
  }
}
