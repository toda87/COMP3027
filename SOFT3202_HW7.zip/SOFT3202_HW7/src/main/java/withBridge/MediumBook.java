package withBridge;

public class MediumBook implements BookLength{

  @Override
  public String getBookLength() {
    return "this is a medium book";
  }
}
