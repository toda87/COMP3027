package withBridge;

public class EBook implements BookType{

  @Override
  public String getBookType() {
    return "This is an EBook";
  }
}
