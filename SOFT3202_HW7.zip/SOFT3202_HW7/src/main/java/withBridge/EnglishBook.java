package withBridge;

public class EnglishBook implements BookLanguage{

  @Override
  public String getLanguageOutput() {
    return "This is a English book";
  }
}
