package withBridge;

public interface Book {
 void read();
}
