package withBridge;

public class LongBook implements BookLength{

  @Override
  public String getBookLength() {
    return "this is a long book";
  }
}
