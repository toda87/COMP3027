package withBridge;

public class ShortBook implements BookLength{

  @Override
  public String getBookLength() {
    return "This is a short book";
  }
}
