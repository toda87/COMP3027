package withBridge;

public class HardcoverBook implements BookType{

  @Override
  public String getBookType() {
    return "This is a hardcover book";
  }
}
