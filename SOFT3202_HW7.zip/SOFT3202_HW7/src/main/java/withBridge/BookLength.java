package withBridge;

public interface BookLength {
  String getBookLength();
}
