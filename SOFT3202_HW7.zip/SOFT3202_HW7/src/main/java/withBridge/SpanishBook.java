package withBridge;

public class SpanishBook implements BookLanguage{

  @Override
  public String getLanguageOutput() {
    return "This is a Spanish book";
  }
}
