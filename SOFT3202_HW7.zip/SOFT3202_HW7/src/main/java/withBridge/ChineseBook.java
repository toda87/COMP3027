package withBridge;

public class ChineseBook implements BookLanguage{

  @Override
  public String getLanguageOutput() {
    return "This is a Chinese book";
  }
}
