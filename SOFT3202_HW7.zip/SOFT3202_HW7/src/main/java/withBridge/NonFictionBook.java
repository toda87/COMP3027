package withBridge;

public class NonFictionBook implements BookLiterature {

  @Override
  public String getLiteratureType() {
    return "This is a non-fiction book";
  }
}
