package withBridge;

public interface BookLanguage {
  String  getLanguageOutput();
}
