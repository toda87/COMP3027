package withBridge;

public interface BookLiterature {
  String  getLiteratureType();
}
