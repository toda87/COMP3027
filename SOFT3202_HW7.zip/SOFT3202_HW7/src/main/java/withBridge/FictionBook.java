package withBridge;

public class FictionBook implements BookLiterature {

  @Override
  public String getLiteratureType() {
    return "This is a fiction book";
  }
}
