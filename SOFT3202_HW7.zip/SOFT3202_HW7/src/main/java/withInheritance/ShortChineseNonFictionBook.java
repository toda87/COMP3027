package withInheritance;

public abstract class ShortChineseNonFictionBook extends ShortChineseBook{
  protected String  getLiteratureType() {
    return "This is non-fiction";
  }
}
