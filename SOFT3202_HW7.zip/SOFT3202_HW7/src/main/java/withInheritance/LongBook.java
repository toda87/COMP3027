package withInheritance;

public abstract class LongBook implements Book{
  protected String getLengthOutput(){return "This is a long book";}
}
