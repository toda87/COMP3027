package withInheritance;

public interface Book {
  void read();
}
