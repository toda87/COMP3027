package withInheritance;

public abstract class MediumChineseBook extends MediumBook{
  protected String  getLanguageOutput() {
    return "This is in Chinese";
  }
}
