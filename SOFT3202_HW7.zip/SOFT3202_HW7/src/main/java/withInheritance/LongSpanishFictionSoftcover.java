package withInheritance;

public class LongSpanishFictionSoftcover extends LongSpanishFictionBook {
  @Override
  public void read(){
    System.out.println("This is softcover");
    System.out.println(super.getLanguageOutput());
    System.out.println(super.getLengthOutput());
    System.out.println(super.getLiteratureType());
  }
}
