package withInheritance;

public abstract class LongChineseFictionBook extends LongChineseBook{
  protected String  getLiteratureType() {
    return "This is fiction";
  }
}
