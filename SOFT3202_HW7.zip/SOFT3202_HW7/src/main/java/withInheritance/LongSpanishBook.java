package withInheritance;

public abstract class LongSpanishBook extends LongBook{
  protected String  getLanguageOutput() {
    return "This is in Spanish";
  }
}

