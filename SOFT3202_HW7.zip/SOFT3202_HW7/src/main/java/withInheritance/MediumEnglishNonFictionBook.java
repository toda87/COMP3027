package withInheritance;

public abstract class MediumEnglishNonFictionBook extends MediumEnglishBook{
  protected String  getLiteratureType() {
    return "This is non-fiction";
  }
}
