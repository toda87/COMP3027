package withInheritance;

public abstract class ShortSpanishNonFictionBook extends ShortSpanishBook{
  protected String  getLiteratureType() {
    return "This is non-fiction";
  }
}
