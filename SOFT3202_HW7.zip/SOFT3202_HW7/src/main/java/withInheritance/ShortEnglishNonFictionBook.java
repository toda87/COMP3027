package withInheritance;

public abstract class ShortEnglishNonFictionBook extends ShortEnglishBook{
  protected String  getLiteratureType() {
    return "This is non-fiction";
  }
}
