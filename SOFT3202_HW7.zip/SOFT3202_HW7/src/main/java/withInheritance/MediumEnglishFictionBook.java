package withInheritance;

public abstract class MediumEnglishFictionBook extends MediumEnglishBook{
  protected String  getLiteratureType() {
    return "This is fiction";
  }
}
