package withInheritance;

public abstract class MediumChineseFictionBook extends MediumChineseBook{
  protected String  getLiteratureType() {
    return "This is fiction";
  }
}
