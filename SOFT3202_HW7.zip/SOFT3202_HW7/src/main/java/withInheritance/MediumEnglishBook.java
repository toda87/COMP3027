package withInheritance;

public abstract class MediumEnglishBook extends MediumBook{
  protected String  getLanguageOutput() {
    return "This is in English";
  }
}
