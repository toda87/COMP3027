package withInheritance;

public class ShortChineseFictionHardcover extends ShortChineseFictionBook{
  @Override
  public void read(){
    System.out.println("This is hardcover");
    System.out.println(super.getLanguageOutput());
    System.out.println(super.getLengthOutput());
    System.out.println(super.getLiteratureType());
  }
}
