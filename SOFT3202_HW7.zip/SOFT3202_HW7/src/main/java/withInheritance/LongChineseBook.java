package withInheritance;

public abstract class LongChineseBook extends LongBook{
  protected String  getLanguageOutput() {
    return "This is in Chinese";
  }
}
