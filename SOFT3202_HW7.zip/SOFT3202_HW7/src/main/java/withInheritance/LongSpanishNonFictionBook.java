package withInheritance;

public abstract class LongSpanishNonFictionBook extends LongSpanishBook {
  protected String  getLiteratureType() {
    return "This is non-fiction";
  }
}
