package withInheritance;

public abstract class ShortSpanishBook extends ShortBook{
  protected String  getLanguageOutput() {
    return "This is in Spanish";
  }
}
