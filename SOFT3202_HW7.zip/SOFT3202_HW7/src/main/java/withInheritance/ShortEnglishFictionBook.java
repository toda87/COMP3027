package withInheritance;

public abstract class ShortEnglishFictionBook extends ShortEnglishBook{
  protected String  getLiteratureType() {
    return "This is fiction";
  }
}
