package withInheritance;

public class LongChineseNonFictionSoftcover extends LongChineseNonFictionBook{
  @Override
  public void read(){
    System.out.println("This is softcover");
    System.out.println(super.getLanguageOutput());
    System.out.println(super.getLengthOutput());
    System.out.println(super.getLiteratureType());
  }
}
