package withInheritance;

public abstract class ShortChineseFictionBook extends ShortChineseBook{
  protected String  getLiteratureType() {
    return "This is fiction";
  }
}
