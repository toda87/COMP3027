package withInheritance;

public abstract class MediumSpanishFictionBook extends MediumSpanishBook{
  protected String  getLiteratureType() {
    return "This is fiction";
  }
}
