package withInheritance;

public abstract class ShortChineseBook extends ShortBook{
  protected String  getLanguageOutput() {
    return "This is in Chinese";
  }
}
