package withInheritance;

public abstract class LongEnglishNonFictionBook extends LongEnglishBook{
  protected String  getLiteratureType() {
    return "This is non-fiction";
  }
}
