package withInheritance;

public abstract class ShortEnglishBook extends ShortBook{
  protected String  getLanguageOutput() {
    return "This is in English";
  }
}
