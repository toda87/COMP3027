package withInheritance;

public class LongChineseFictionEbooks extends LongChineseFictionBook{
  @Override
  public void read(){
    System.out.println("This is EBook");
    System.out.println(super.getLanguageOutput());
    System.out.println(super.getLengthOutput());
    System.out.println(super.getLiteratureType());
  }
}
