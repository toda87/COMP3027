package withInheritance;

public class LongChineseFictionSoftcover extends LongChineseFictionBook{
  @Override
  public void read(){
    System.out.println("This is softcover");
    System.out.println(super.getLanguageOutput());
    System.out.println(super.getLengthOutput());
    System.out.println(super.getLiteratureType());
  }
}
