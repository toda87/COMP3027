package withInheritance;

public abstract class LongEnglishBook extends LongBook{
  protected String  getLanguageOutput() {
    return "This is in English";
  }
}
