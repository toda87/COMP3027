package withInheritance;

public abstract class MediumSpanishNonFictionBook extends MediumSpanishBook{
  protected String  getLiteratureType() {
    return "This is non-fiction";
  }
}
