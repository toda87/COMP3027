package withInheritance;

public abstract class MediumBook implements Book{
  protected String getLengthOutput(){return "This is a medium book";}
}
