package withInheritance;

public abstract class LongSpanishFictionBook extends LongSpanishBook{
  protected String  getLiteratureType() {
    return "This is fiction";
  }
}
