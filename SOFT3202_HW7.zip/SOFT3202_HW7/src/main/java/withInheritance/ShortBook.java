package withInheritance;

public abstract class ShortBook implements Book{
  protected String getLengthOutput(){return "This is a short book";}
}
