package withInheritance;

public abstract class ShortSpanishFictionBook extends ShortSpanishBook{
  protected String  getLiteratureType() {
    return "This is fiction";
  }
}
