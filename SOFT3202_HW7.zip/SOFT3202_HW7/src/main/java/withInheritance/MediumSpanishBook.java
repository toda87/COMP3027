package withInheritance;

public abstract class MediumSpanishBook extends MediumBook{
  protected String  getLanguageOutput() {
    return "This is in Spanish";
  }
}
