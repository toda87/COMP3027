import javafx.util.Pair;

import java.util.List;

/**
 * Member of the store
 */
public class Member {

  private ShoppingBasket sb = new ShoppingBasket();

  /**
   * Default constructor.
   */
  public Member() {
  }

  /**
   * @param product   The product to be selected. May not be null.
   * @param quantity  The number of units of the product to be selected. Must be 1 or more.
   * @param inventory The inventory that holds the number of products. Should not be null.
   * @throws IllegalArgumentException if any of the parameter preconditions are breached.
   * @throws IllegalStateException    if the global inventory does not have the required amount of
   *                                  Product.
   */
  public void selectProduct(Product product, int quantity, Inventory inventory)
      throws IllegalArgumentException, IllegalStateException {
    if (null == product || quantity < 1 || null == inventory) {
      throw new IllegalArgumentException();
    }
    if (inventory.getProductQuantity(product) < quantity) {
      throw new IllegalStateException();
    }
    inventory.takeProduct(product, quantity);
    sb.addItem(product, quantity);
  }

  /**
   * @param product   The product to be returned.
   * @param quantity  The number of units of the product to be returned.
   * @param inventory The inventory that holds the number of products. Should not be null.
   * @throws IllegalArgumentException if any of the parameter preconditions are breached.
   * @throws IllegalStateException    if the Member's basket does not contain the required amount of
   *                                  Product.
   */
  //Does not have any preconditions on parameter, but have exception handling, so I will assume that its the same for selectProduct()
  public void returnProduct(Product product, int quantity, Inventory inventory)
      throws IllegalArgumentException, IllegalStateException {
    if (null == product || quantity < 1 || null == inventory) {
      throw new IllegalArgumentException();
    }
    if (sb.removeItem(product, quantity)) {
      inventory.addProduct(product, quantity);
    } else {
      throw new IllegalStateException();
    }
  }

  /**
   * Finalise the payment. Do not charge anything if the basket is empty.
   */
  public void finalisePurchases() {
    Double charge = sb.getValue();

    if (null == charge) {
      System.out.println("There is nothing in the basket. Good bye.");
    } else {
      System.out.println(
          "Thank you for purchasing. The total charge is " + charge);
    }
    sb.clear();
  }
}
