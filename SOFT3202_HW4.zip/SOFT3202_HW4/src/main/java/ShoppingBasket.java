//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javafx.util.Pair;

/**
 * Stores products a member has selected
 */
public class ShoppingBasket {

  private final Map<Product, Integer> map = new HashMap();

  /**
   * Default constructor.
   */
  public ShoppingBasket() {
  }

  /**
   * Add a product to this ShoppingBasket. Will combine and sum duplicate item counts if
   * encountered.
   *
   * @param product The product to add. May not be null.
   * @param count   The number of units of the product to add. Must be 1 or more.
   * @throws IllegalArgumentException if any of the parameter preconditions are breached.
   */
  public void addItem(Product product, int count) throws IllegalArgumentException {
    if (null == product) {
      throw new IllegalArgumentException("product should not be null");
    }
    if (count <= 0) {
      throw new IllegalArgumentException("quantity should be more than 0.");
    }
    if (!map.containsKey(product)) {
      map.put(product, 0);
    }
    map.put(product, map.get(product) + count);
  }

  /**
   * Removes a product from this ShoppingBasket if and only if the given count or more was contained
   * in the ShoppingBasket. If this brings the total count of that product to zero, the product
   * entry is removed entirely.
   *
   * @param product The product to remove. May not be null.
   * @param count   The number of units of the product to remove. Must be 1 or more.
   * @return True if the given count of more of the given product were contained in the
   * ShoppingBasket and thus removed. Otherwise false.
   * @throws IllegalArgumentException if any of the parameter preconditions were breached.
   */
  public boolean removeItem(Product product, int count) throws IllegalArgumentException {
    if (null == product) {
      throw new IllegalArgumentException("product should not be null");
    }
    if (count <= 0) {
      throw new IllegalArgumentException("quantity should be more than 0.");
    }

    //check if the product is contained
    if (map.containsKey(product)) {
      //If member wants to remove more than he/she has, return false
      if (map.get(product) >= count) {
        if (map.get(product) == count) {
          map.remove(product);
        } else {
          map.put(product, map.get(product) - count);
        }
        return true;
      }
    }
    return false;
  }

  /**
   * Retrieves a list of each Product and count of units currently contained by this
   * ShoppingBasket.
   *
   * @return The list of Products and count of units by Pair. Minimum count per product is 1.
   */
  public List<Pair<Product, Integer>> getItems() {
    List<Pair<Product, Integer>> result = new ArrayList();
    Iterator var2 = this.map.keySet().iterator();

    while (var2.hasNext()) {
      Product item = (Product) var2.next();
      result.add(new Pair(item, this.map.get(item)));
    }

    return result;
  }

  /**
   * Sums the prices of each unit of each product in this ShoppingBasket
   *
   * @return The total price of the ShoppingBasket contents.
   */
  public Double getValue() {
    if (map.isEmpty()) {
      return null;
    } else {
      double result = 0;

      Iterator it = this.map.keySet().iterator();

      while (it.hasNext()) {
        Product item = (Product) it.next();
        result += (map.get(it) * item.getPrice());
      }

      // round up to second decimal to ignore non-significant bit of double value.
      return (double) (Math.round(result * 100) / 100);
    }
  }

  /**
   * Empties the ShoppingBasket
   */
  public void clear() {
    this.map.clear();
  }
}
